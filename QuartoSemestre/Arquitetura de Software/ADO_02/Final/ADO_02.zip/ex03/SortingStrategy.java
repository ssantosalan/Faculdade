package ex03;

public interface SortingStrategy {
	int[] sort(int[] inputArray);
}
