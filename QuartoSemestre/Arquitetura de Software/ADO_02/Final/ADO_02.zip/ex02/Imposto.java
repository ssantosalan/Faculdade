package ex02;

public class Imposto {
	private double imposto;

    public Imposto(double imposto) {
        this.imposto = imposto;
    }

    public double getImposto() {
        return imposto;
    }

}
