package ex02;

public interface Empresas {
	public abstract double calcularImposto(Imposto imposto, Orcamento empresa);
}
