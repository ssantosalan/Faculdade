package ex04;

public interface DepartamentoComponent {
	public Double getCusto(); 
	public Integer getFuncionarios();

}
