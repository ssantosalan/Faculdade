
package batalhatanques;


public interface Canhao {
       public void atirar();

}
