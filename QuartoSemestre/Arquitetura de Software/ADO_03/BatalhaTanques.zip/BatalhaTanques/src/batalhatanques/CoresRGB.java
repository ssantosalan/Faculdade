
package batalhatanques;

public enum CoresRGB {
    RED,GREEN,BLUE;
}
