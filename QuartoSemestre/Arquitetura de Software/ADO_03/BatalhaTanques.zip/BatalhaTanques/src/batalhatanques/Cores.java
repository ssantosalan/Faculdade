
package batalhatanques;

public interface Cores {
    public void setCorTanque(CoresRGB cor);
    public CoresRGB getCorTanque();
    public CoresRGB getCorCanhao();
    public void setCorCanhao(CoresRGB cor);

}
