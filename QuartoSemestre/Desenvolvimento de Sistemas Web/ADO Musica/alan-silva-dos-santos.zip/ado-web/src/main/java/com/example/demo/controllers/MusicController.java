package com.example.demo.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.example.demo.domain.Music;
import com.example.demo.domain.dtos.MusicDTO;
import com.example.demo.services.MusicService;

import jakarta.validation.Valid;

@Controller
@RequestMapping("musicas")
public class MusicController {

	@Autowired
	private MusicService service;

	@GetMapping("/nova")
	public ModelAndView novaMusica(MusicDTO musicDTO) {
		ModelAndView mv = new ModelAndView("createMusic");
		return mv;
	}

	@GetMapping
	public ModelAndView findAll() {
		List<Music> lista = service.findAll();
		ModelAndView mv = new ModelAndView("getMusic");
		mv.addObject("lista", lista);
		return mv;
	}

	@PostMapping("salvar")
	public ModelAndView create(@Valid MusicDTO musicDTO, BindingResult br) {
		if (br.hasErrors()) {
			return new ModelAndView("createMusic");
		}
		service.create(musicDTO);
		ModelAndView mv = new ModelAndView("redirect:/musicas");
		return mv;
	}
}
