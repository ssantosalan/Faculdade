package com.example.demo.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.domain.Music;
import com.example.demo.domain.dtos.MusicDTO;
import com.example.demo.repositories.MusicRepository;

@Service
public class MusicService {

	@Autowired
	private MusicRepository repository;

	public List<Music> findAll() {
		return repository.findAll();
	}

	public void create(MusicDTO dto) {
		Music musica = new Music(dto);
		repository.save(musica);
	}
}
