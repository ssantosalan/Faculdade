package com.example.demo.domain.dtos;

import org.springframework.stereotype.Component;

import com.example.demo.domain.Music;

import jakarta.validation.constraints.NotBlank;

@Component
public class MusicDTO {

	@NotBlank(message = "Informe o Título")
	private String titulo;

	@NotBlank(message = "Informe o Artista")
	private String artista;

	@NotBlank(message = "Informe o Lançamento")
	private String lancamento;

	public MusicDTO(Music musica) {
		this.titulo = musica.getTitulo();
		this.artista = musica.getArtista();
		this.lancamento = musica.getLancamento();
	}

	public MusicDTO() {
	}

	public String getTitulo() {
		return titulo;
	}

	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}

	public String getArtista() {
		return artista;
	}

	public void setArtista(String artista) {
		this.artista = artista;
	}

	public String getLancamento() {
		return lancamento;
	}

	public void setLancamento(String lancamento) {
		this.lancamento = lancamento;
	}

}
