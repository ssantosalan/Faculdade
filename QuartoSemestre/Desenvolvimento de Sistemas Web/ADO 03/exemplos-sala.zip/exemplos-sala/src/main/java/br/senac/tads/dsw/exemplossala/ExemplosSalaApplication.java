package br.senac.tads.dsw.exemplossala;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExemplosSalaApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExemplosSalaApplication.class, args);
	}

}
